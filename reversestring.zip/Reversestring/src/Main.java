import java.util.Scanner;

import week9.in;
public class Main {

	public static void main(String[] args) {
		
		Scanner sEn = new Scanner(System.in);
		System.out.println("Enter Your Sentence");
		
	    String s = sEn.nextLine();
	    System.out.println(s);
	    
	    String a = reverse(s); 
	    System.out.println(a);
	}
	    
	   public static String reverse(String a) {
	    		char [] letters = new char [a.length()];
	            int letterIndex = 0;
	    		for(int i = a.length() - 1; i >= 0; i--) {
	    			letters[letterIndex] = a.charAt(i);
	    			letterIndex++;
	    			
	    		}
	    		
	    		String reverse ="";
	    		for(int i=0; i < a.length(); i++)
	    			reverse = reverse + letters[i];
	    		
	    		return reverse;
	    	}
	    }
	
	



